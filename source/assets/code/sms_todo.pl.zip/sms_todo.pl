#!/usr/bin/perl -w

############################################################################
# This is a sample script to create next actions from an incoming email.   #
# It is meant to receive emails from procmail, or some other mail filter.  #
# It can be used to create next actions from SMS text messages, which can  #
# be sent as emails.                                                       #
# Use this example procmail filter to make it work:                        #
#:0fw: todo.lock                                                           #
#* ^From:MYPHONENUMBER@MYPROVIDER.com                                      #
#| todo.pl                                                                 #
############################################################################

use strict;
use Frontier::Client;
use DBI;

my $HOST = 'localhost';

my $PORT = '3000';

my $client = new Frontier::Client(url => "http://$HOST:$PORT/backend/api");

# Replace with your username/password
my $username = "username";

# you can get the value for your password by doing a query against the db
# select login,word from users where login like "username";
my $token = "3ef648db7e72c825b45ac6d94e80dd19d25de556";

# This is the name of the database, database user, and database password
my $dbh = DBI->connect('dbi:mysql:tracksdb', 'username', 'password');

# Parse the incoming email, and get the body
# Format is "[Next action]. Context [context]."
# Associating a project or note is not supported yet
my $toggle = 0;
my ($body, $description, $context);

while (<>) {
    if (/^\s*$/) {
	$toggle = 1;
	next;
    }
    if ($toggle) {
	$body = $_;
    }
}

if ($body =~ /^(.*?)\./) {
    $description = $1;
    if ($body =~ /\. Context (.*?)\./) {
	$context = $1;
    }
}

my $context_id = $dbh->selectrow_array("select id from contexts where name like \"$context\"");

# now make the request to tracks and add your task
my $request = $client->call('NewTodo', $username, $token, $context_id, $description);

$dbh->disconnect();