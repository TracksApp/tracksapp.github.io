#!/usr/bin/perl -w

use strict;
use Frontier::Client;

############################################################################
# This is a sample script for adding ToDos to Tracks using the new API     #
# The API is currently available using XMLRPC: http,//www.xmlrpc.com/      #
#                                                                          #
# It uses the Frontier modules, available from,                            #
#                                                                          #
# http,//theoryx5.uwinnipeg.ca/mod_perl/cpan-search?dist=Frontier-RPC      #
#                                                                          #
############################################################################

# Define the host first. 
my $HOST = 'localhost';

my $PORT = '3000';
# Now we create the client object that will be used throughout the session.

my $client = new Frontier::Client(url => "http://$HOST:$PORT/backend/api");

# Replace with your username/password 
my $username = "username";

# you can get the value for your password by doing a query against the db
# select login,word from users where login like "username";
my $token = "3ef648db7e72c825b45ac6d94e80dd19d25de556";

# To get the context_id:
# select id,name from contexts where name like "context_name";

my $context_id = "8";
my $description = "This is a test";

# now make the request to tracks and add your task
my $request = $client->call('NewTodo', $username, $token, $context_id, $description);

# All you need to do is modify the script to take arguments and perhaps 
# look up the actual values in the db for you.
