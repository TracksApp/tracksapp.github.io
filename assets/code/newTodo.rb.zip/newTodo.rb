#!/usr/bin/env ruby

#   NewTodo: add a next action in Tracks
#
#   Copyright (c) 2006 - Damien Cirotteau - d@cirotteau.info
#
#   This is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or (at
#   your option) any later version.
# 
#   This program is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#   General Public License for more details.
# 
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
#   USA.
#
#
#   Usage: newTodo [options] "description"
#       -n, --name ARG                   Your user name in Tracks
#       -t, --token ARG                  Your personal token
#       -c, --context ARG                The context of your next action
#       -s, --server ARG                 The server where to upload your next action
#

require 'xmlrpc/client'
require 'pp'
require 'optparse'

class Todo
	def initialize(contextID, description)
		@contextID = contextID
		@description = description
	end
	attr_reader :contextID, :description
	attr_writer :contextID, :description

	def upload(name, token, server)
		server = XMLRPC::Client.new2(server)
		server.call("NewTodo", name, token, @contextID, @description)
	end
end

# Change the parameters with your own info
myUserName = "user_name"
myToken = "token"
myContextID = 1
myServer = "http://localhost:3000/backend/api"
myDescription = "Default description"

# parse the command line option and change the default value if necessary
opts = OptionParser.new
opts.on("-n", "--name ARG", String, "Your user name in Tracks") {|val| myUserName = val}
opts.on("-t", "--token ARG", String, "Your personal token") {|val| myToken = val}
opts.on("-c", "--context ARG", Integer, "The context of your next action") {|val| myContextID = val}
opts.on("-s", "--server ARG", String, "The server where to upload your next action") {|val| myServer = val}
rest = opts.parse(*ARGV)

# the argument on the command line is the description of the todo
myDescription = rest[0][0..99]

puts myDescription
newTodo = Todo.new(myContextID, myDescription)
newTodo.upload(myUserName, myToken, myServer)

